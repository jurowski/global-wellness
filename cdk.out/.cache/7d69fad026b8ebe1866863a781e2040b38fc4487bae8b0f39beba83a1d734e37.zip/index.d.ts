export declare const handler: () => Promise<void>;
